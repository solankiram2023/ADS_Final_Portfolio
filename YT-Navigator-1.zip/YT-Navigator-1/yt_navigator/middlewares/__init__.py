"""Middlewares for the yt_navigator app."""
