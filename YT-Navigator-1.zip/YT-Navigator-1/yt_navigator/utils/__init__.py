"""Utils for the yt_navigator app."""
