"""Admin configuration for the app."""

from django.contrib import admin

# Register your models here.
