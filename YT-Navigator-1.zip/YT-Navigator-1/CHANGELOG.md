# Changelog

## 0.1.2 - 2025-03-16

### Added
- Added Langsmith dataset creation and example addition
### Known Issues
- Poor exception handling
- UI responsiveness issues on mobile devices
- Supports only English for now
